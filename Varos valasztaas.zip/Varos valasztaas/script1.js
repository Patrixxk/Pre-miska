"use strict";
const modal = document.querySelector(".modal");

const cities = ["Miskolc", "Budapest", "Kassa", "Zsolna", " Debrecen", "Eger"];

const modal1 = document.querySelector(".show-modal1");
const modal2 = document.querySelector(".show-modal2");
const modal3 = document.querySelector(".show-modal3");
const modal4 = document.querySelector(".show-modal4");
const modal5 = document.querySelector(".show-modal5");
const modal6 = document.querySelector(".show-modal6");

const array = [];

const show = function () {
  modal.classList.remove("hidden");
};

modal1.addEventListener("click", function () {
  document.querySelector(".show-modal1").textContent = cities[0];
  array.push(cities[0]);
});
modal2.addEventListener("click", function () {
  document.querySelector(".show-modal2").textContent = cities[1];
  array.push(cities[1]);
});

modal3.addEventListener("click", function () {
  document.querySelector(".show-modal3").textContent = cities[2];
  array.push(cities[2]);
});

modal4.addEventListener("click", function () {
  document.querySelector(".show-modal4").textContent = cities[3];
  array.push(cities[3]);
});

modal5.addEventListener("click", function () {
  document.querySelector(".show-modal5").textContent = cities[4];
  array.push(cities[4]);
});

modal6.addEventListener("click", function () {
  document.querySelector(".show-modal6").textContent = cities[5];
  array.push(cities[5]);
});
console.log(array);

const randomgen = (arr) => {
  arr[Math.floor(Math.random() * arr.length)];
};
randomgen(array);

document.querySelector(".message").textContent = randomgen;
console.log(randomgen(array));
